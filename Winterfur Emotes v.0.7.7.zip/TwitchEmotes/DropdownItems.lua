-- 45 per menu max
TwitchEmotes_dropdown_options = {
    [1] = { -- 44
        "winterfur1", "bearstab", "amaze", "wfbonk", "bunnyheart", "blobshtap", 
        "blobmoop", "blobmiku", "blobmeep", "blobcute", "blobno", "blobyes",
        "bunnysad", "concern", "crymoji", "frog_heart", "hatquisition", "wfhelike",
        "hyperbee", "mopmentioned", "nekopray", "skullsob", "wheeze", "wflendelyn",
        "wfpanic", "panichat", "wfrue", "rue_giga_brain", "wfmeow", "wfaww",
        "bearcop", "bearnote", "blahajhug", "blobcheer", "nodnods", "bongocatlove",
        "run_pengu", "helizard", "foxpats", "wigglepidgeon", "bearwave", "bearrage",
        "rue_wall", "peenus", "blobrawr"
    },
    [2] = { -- 
        "winterfur2", "wfyibbles", "wfteabag", "wfsalute", "wfowo", "blushies",
        "blushthink", "bearcave", "blobtrash", "nekojail", "winterfurlogo", "huggies",
        "angyartist", "wfelroina", "elstare", "elglow", "yodders", "meangy", "pensivebear"
    }
};